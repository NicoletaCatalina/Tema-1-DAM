package com.ase.dam.seminar2.utils;

import java.io.Serializable;

//implementând interfața Serializable, obiectul devine de tip Serializable și poate fi transmis dintr-o activitate către alta
public class User implements Serializable {
    String name;
    int idUser;

    public User(String name, int id) {
        this.name = name;
        this.idUser = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }
}
