package com.ase.dam.seminar2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.ase.dam.seminar2.firebase.FirebaseController;
import com.ase.dam.seminar2.utils.Movie;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddMovieActivity extends AppCompatActivity {
    //declarare obiect de tip Spinner
    public static final String MOVIE_KEY = "sendMovie";

    String DATE_FORMAT = "dd-MM-yyyy";
    DateFormat simpleDateFormat = new SimpleDateFormat(DATE_FORMAT, Locale.US);

    EditText etTitle, etRealeaseDate, etProfit;
    Spinner spinnerGenre;
    RadioGroup rgPlatform;
    Button btnSave;
    Intent intent;
    FirebaseController firebaseController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //metoda care are rolul de a face legatura intre fisierul de tip .java asociat activitatii si fisierul xml asociat acesteia
        setContentView(R.layout.activity_add_movie);
        intent = getIntent();
        initComponents();
    }

    //metoda folosită pentru initializarea tuturor componentelor vizuale
    private void initComponents() {
        etTitle = findViewById(R.id.etMovieTitle);
        etRealeaseDate = findViewById(R.id.etDate);
        etProfit = findViewById(R.id.etProfit);
        spinnerGenre = findViewById(R.id.spinnerMovieGenre);
        firebaseController = new FirebaseController();

        //crearea unui adaptor
        ArrayAdapter<CharSequence> adapterMovieGenre = ArrayAdapter.createFromResource(getApplicationContext(),R.array.movie_genre, R.layout.support_simple_spinner_dropdown_item);
        //atasarea unui adaptor pe un spinner
        //crearea adaptorului nu este suficienta, este nevoie asocierea element grafic-adaptor pentru ca datele sa fie transferate spre elementul grafic
        spinnerGenre.setAdapter(adapterMovieGenre);
        rgPlatform = findViewById(R.id.rgPlatform);
        btnSave = findViewById(R.id.btnSave);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(validation()) {
                    Movie movie = createMovie();
                    if(movie != null) {
                        firebaseController.addMovieInFirebase(movie);
                        intent.putExtra(MOVIE_KEY, movie);
                        //metoda utilizata pentru a intoarce rezultatele asteptate de activitatea apelator.
                        // Metoda primeste doi parametri:
                        //resultCode - se marcheaza tipul de raspuns (pentru un rezultat corect se utilizeaza RESULT_OK);
                        //data - Intentul cu care s-a deschis activitatea si care contine informatiile pe care dorim sa le transmitem.
                        setResult(RESULT_OK, intent);
                        //finish() -> metoda utilizata pentru a finaliza ciclul de viata al unei activitati.
                        finish();
                    }
                }
            }
        });
    }

    //metoda care are scopul de a ne asigura ca exista valori introduse de utilizator in EditText
    private boolean validation() {

        //trim() -> metoda care returneaza o copie a String-ului, dar fara spatii
        if(etTitle.getText() == null || etTitle.getText().toString().trim().isEmpty()) {
            Toast.makeText(getApplicationContext(), R.string.add_movie_title_error, Toast.LENGTH_LONG).show();
            return false;
        }

        if(etRealeaseDate.getText() == null || etRealeaseDate.getText().toString().trim().isEmpty()) {
            Toast.makeText(getApplicationContext(), R.string.add_movie_release_date_error, Toast.LENGTH_LONG).show();
            return false;
        }

        if(etProfit.getText() == null || etProfit.getText().toString().trim().isEmpty()) {
            Toast.makeText(getApplicationContext(), R.string.add_movie_profit_error, Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    //metoda care are rolul de a prelua datele introduse de utilizator si a crea obiectul de tip Movie
    private Movie createMovie(){
            String title = etTitle.getText().toString();
            String releaseDate = etRealeaseDate.getText().toString();
            int profit = Integer.parseInt(etProfit.getText().toString());
            String movieGenre = spinnerGenre.getSelectedItem().toString();
            RadioButton checkedButton= findViewById(
                    rgPlatform.getCheckedRadioButtonId());
            String platform = checkedButton.getText().toString();
            return new Movie(title,releaseDate,profit,movieGenre,platform);
    }

}