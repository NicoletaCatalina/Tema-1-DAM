package com.ase.dam.seminar2.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;

public interface Constants {
    public String DATE_PATTERN = "dd-MM-yyyy";
    //este o clasa din Java utilizata pentru conversia de la String la Date, respectiv de la Date la String
    //primeste un format de data pe care sa-l aplice in timpul conversie
    //constructorul conține și un al doilea parametru care identifică tipul regiunii în care urmează să fie folosită data
    public DateFormat simpleDateFormat = new SimpleDateFormat(DATE_PATTERN, Locale.US);
}
