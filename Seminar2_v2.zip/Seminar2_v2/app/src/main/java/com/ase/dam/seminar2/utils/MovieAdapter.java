package com.ase.dam.seminar2.utils;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ase.dam.seminar2.R;

import java.util.List;

//adaptor personalizat prin extinderea clasei ArrayAdapter
public class MovieAdapter extends ArrayAdapter {
    TextView tvTitle, tvReleaseDate, tvProfit, tvPlatform, tvGenre;
    private int resource;
    private List<Movie> objects;
    private LayoutInflater inflater;

    //constructorul adaptorului personalizat care primeste patru parametrii:
    //1.contextul
    //2.resource -> id-ul resursei de tip layout asociat adaptorului personalizat
    //3. objects -> lista de obiecte care trebuie trasnmisa AdapterView-ului prin adaptor
    //4. LayoutInflater -> obiectul care face legatura cu fisierul de resurse de tip layout
    public MovieAdapter(@NonNull Context context, int resource, @NonNull List objects, LayoutInflater inflater) {
        super(context, resource, objects);

        this.resource = resource;
        this.objects = objects;
        this.inflater = inflater;
    }

    //metoda folosita pentru initializarea si transmiterea datelor catre rand
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        //asocierea fisierului de tip layout cu randul care va fi completat cu date
        View row = inflater.inflate(this.resource, parent, false);

        //initializarea elementelor vizuale din fisierul de tip layout asociat randului
        tvTitle = row.findViewById(R.id.tvMovieTitle);
        tvReleaseDate = row.findViewById(R.id.tvReleaseDate);
        tvProfit = row.findViewById(R.id.tvProfit);
        tvPlatform = row.findViewById(R.id.tvPlatform);
        tvGenre = row.findViewById(R.id.tvMovieGenre);

        //preularea obiectului din lista de pe o anumita pozitie
        Movie movie = objects.get(position);

        //setarea datelor in elementele vizuale
        tvTitle.setText(movie.getTitle());
        tvReleaseDate.setText("Release date:" + movie.getReleaseDate());
        tvProfit.setText("Profit:" + movie.getProfit());
        tvGenre.setText(movie.getMovieGenre());
        tvPlatform.setText(movie.getPlatform());

        return row;
    }
}
