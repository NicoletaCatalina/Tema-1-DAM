package com.ase.dam.seminar2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.ase.dam.seminar2.firebase.FirebaseController;
import com.ase.dam.seminar2.utils.Movie;
import com.ase.dam.seminar2.utils.User;

public class UpdateActivity extends AppCompatActivity {
    EditText etMovieTile;
    Button btnUpdate;
    Intent intent;
    FirebaseController firebaseController;

    public static final String MOVIE_KEY = "sendMovie";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //metoda care are rolul de a face legatura intre fisierul de tip .java asociat activitatii si fisierul xml asociat acesteia
        setContentView(R.layout.update_dialog);
        intent = getIntent();
        initComponents();
    }

    private void initComponents() {
        etMovieTile = findViewById(R.id.Ilie_Nicoleta_etMovieTitleUpdate);
        btnUpdate = findViewById(R.id.Ilie_Nicoleta_btnAlertDialog);
        firebaseController = new FirebaseController();

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(validation())
                {
                    if(getIntent().hasExtra(MainActivity.STRING_KEY)) {

                        Movie movie = (Movie) getIntent().getSerializableExtra(MainActivity.STRING_KEY);
                        String title = etMovieTile.getText().toString();
                        if(movie != null) {
                            movie.setTitle(title);
                            firebaseController.addMovieInFirebase(movie);
                            intent.putExtra(MOVIE_KEY, movie);

                            setResult(RESULT_OK, intent);

                            finish();
                        }
                    }
                }
            }
        });
    }

    private boolean validation() {
        //trim() -> metoda care returneaza o copie a String-ului, dar fara spatii
        if (etMovieTile.getText() == null || etMovieTile.getText().toString().trim().isEmpty()) {
            Toast.makeText(getApplicationContext(), R.string.add_movie_title_error, Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }
}
