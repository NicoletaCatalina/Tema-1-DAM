package com.ase.dam.seminar2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.ase.dam.seminar2.utils.User;

public class AboutActivity extends AppCompatActivity {
    TextView tvUsername, tvUserId, tvInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        tvUsername = findViewById(R.id.textViewUserName);
        tvUserId = findViewById(R.id.textViewAge);
        tvInfo = findViewById(R.id.tvInfo);

        //hasExtra() -> verificarea ca in cheia pe care o primeste ca parametru exista ceva stocat
        if(getIntent().hasExtra(MainActivity.USER_KEY)) {
            //metoda disponibila la nivelul clasei Intent, fiind utilizata pentru preluare unui obiect custom din Intent.
            //clasa obiectului preluat implementeaza interfata Serializable.
            //parametrul de intrare reprezinta cheia pe care s-a salvat obiectiul prin apelul metodei putExtra().
            User user = (User) getIntent().getSerializableExtra(MainActivity.USER_KEY);
            tvUserId.setText(" " + user.getIdUser());
            tvUsername.setText(user.getName());
        }

        if(getIntent().hasExtra(MainActivity.STRING_KEY)) {
            String info = getIntent().getStringExtra(MainActivity.STRING_KEY);
            tvInfo.setText(info);
        }
    }
}