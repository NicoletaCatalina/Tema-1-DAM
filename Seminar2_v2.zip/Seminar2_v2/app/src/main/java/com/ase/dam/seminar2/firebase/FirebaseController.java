package com.ase.dam.seminar2.firebase;

import android.util.Log;

import androidx.annotation.NonNull;

import com.ase.dam.seminar2.utils.Movie;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

//clasa Java responsabila cu operatiile din Firebase
public class FirebaseController {
    //reprezinta o locatie particulara in baza de date care poate fi folosita pentru a scrie sau a citi date
    private DatabaseReference databaseReference;
    private static final String TABLE_NAME = "Movies";
    private static final String FIREBASE_TAG = "FirebaseEvent";



    public FirebaseController() {
        //FirebaseDatabase -> punctul de intrare intr-o baza de date Firebase, care ne da acces la locatie
        //initializarea unui obiect de tip FirebaseDatabase
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        //obtinerea accesului catre locatia din Firebase unde se poate scrie / de unde se poate citi
        databaseReference = db.getReference(TABLE_NAME);
    }



    //metoda care asigura introducerea filmelor in baza de date Firebase
    public void addMovieInFirebase(Movie movie) {
        if(movie != null) {
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    //creeaza un id al intrarii
                    movie.setGlobalId(databaseReference.push().getKey());
                    //salveaza intrarea ca copil, la cheia generata
                    databaseReference.child(movie.getGlobalId()).setValue(movie);
                    Log.i(FIREBASE_TAG, "The movie has been added to firebase database");
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.w(FIREBASE_TAG, "Insert of the movie is not working");
                }
            });
        }
    }

    public void updateMoviesInFirebase(Movie movie, String newTitle) {
        Movie newMovie = new Movie(movie.getGlobalId(), newTitle, movie.getReleaseDate(), movie.getProfit(), movie.getMovieGenre(), movie.getPlatform());
        if(movie != null) {
            databaseReference.child(movie.getGlobalId()).setValue(newMovie);
        }
    }

    public void loadMoviesFromFirebase(ValueEventListener eventListener) {
        if(eventListener != null) {
            //addValueEventListener -> ajuta la detectarea schimbarilor aduse unei intrari din Firebase de la o anumita cale (inclusiv copiii care exista la acea cale)
            //acest listener asculta pe o perioada mai lunga, nu pentru o singura intrare
            databaseReference.addValueEventListener(eventListener);
        }
    }

    public void removeMovie(Movie movie) {
        if(movie != null) {
            databaseReference.child(movie.getGlobalId()).removeValue();
        }
    }



}
