package com.ase.dam.seminar2.utils;

import android.os.Parcel;
import android.os.Parcelable;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

//implementând interfața Parcelable, obiectul devine de tip Parcelable și poate fi transmis dintr-o activitate către alta
public class Movie implements Parcelable {


    private String globalId;
    private String title;
    private String releaseDate;
    private int profit;
    private String movieGenre;
    private String platform;

    public Movie() {}
    //constructorul clasei Movie
    public Movie(String title, String releaseDate, int profit, String movieGenre, String platform) {
        this.title = title;
        this.releaseDate = releaseDate;
        this.profit = profit;
        this.movieGenre = movieGenre;
        this.platform = platform;
    }

    public Movie(String globalId, String title, String releaseDate, int profit, String movieGenre, String platform) {
        this.globalId = globalId;
        this.title = title;
        this.releaseDate = releaseDate;
        this.profit = profit;
        this.movieGenre = movieGenre;
        this.platform = platform;
    }

    //constructorul folosit pentru reconstruirea obiectului Movie din obiectul Parcel trimis între activități
    //!!! atenție ca ordinea campurilor la reconstruirea obietului să fie aceeași ca la salvarea lui în obiectul Parcel
    protected Movie(Parcel in) {
        this.title = in.readString();
        this.releaseDate = in.readString();
        this.profit = in.readInt();
        this.movieGenre = in.readString();
        this.platform = in.readString();
    }

    //metoda care utilizează constructorul folosit pentru reconstruirea obiectului
    //metoda obligatorie atunci când se implementează interfața Parcelable
    //se apelează la primirea obiectului în a doua activitate
    public static final Parcelable.Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel in) {
            return new Movie(in);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    //metoda folosită pentru a salva un obiect de tip Movie într-un obiect de tip Parcel
    //apelată înainte de trimiterea obiectului între activități
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        //format() - utilizata pentru transformarea unui obiect Date în String.
        dest.writeString(this.releaseDate);
        dest.writeInt(profit);
        dest.writeString(this.movieGenre);
        dest.writeString(this.platform);
    }

    @Override
    public int describeContents() {
        return 0;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public int getProfit() {
        return profit;
    }

    public void setProfit(int profit) {
        this.profit = profit;
    }

    public String getMovieGenre() {
        return movieGenre;
    }

    public void setMovieGenre(String movieGenre) {
        this.movieGenre = movieGenre;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getGlobalId() {
        return globalId;
    }

    public void setGlobalId(String globalId) {
        this.globalId = globalId;
    }

    @Override
    public String toString() {
        return "Movie{" +
                "title='" + title + '\'' +
                ", releaseDate=" + releaseDate +
                ", profit=" + profit +
                ", movieGenre=" + movieGenre +
                ", platform=" + platform +
                '}';
    }
}
