package com.ase.dam.seminar2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.ase.dam.seminar2.firebase.FirebaseController;
import com.ase.dam.seminar2.utils.Movie;
import com.ase.dam.seminar2.utils.MovieAdapter;
import com.ase.dam.seminar2.utils.User;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    FloatingActionButton fab, fabSend;
    ListView listView;
    ArrayList<Movie> movieList;
    public static final int REQUEST_CODE = 200;
    List<Movie> moviesFromFirebase = new ArrayList<>();
    DatabaseReference databaseReference;
    FirebaseController firebaseController = new FirebaseController();


    public static final String USER_KEY = "sendUser";
    public static final String STRING_KEY = "sendString";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initializarea obiectelor pe baza id-ului din fișierul XML
        fab = findViewById(R.id.fabMainActivity);
        fabSend = findViewById(R.id.fabSend);
        listView = findViewById(R.id.Ilie_Nicoleta_lvMovies);
        movieList = new ArrayList<>();

        firebaseController.loadMoviesFromFirebase(loadMovies());


        //setarea unui eveniment de click pe un buton
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            //metoda onClick() -> scrierea logicii ce se va intampla la click de buton
            public void onClick(View view) {
                //inițializare obiect de tip Intent
                Intent intent = new Intent(getApplicationContext(), AddMovieActivity.class);
                //inceperea unei alte activitati atunci când se așteaptă un rezultat
                startActivityForResult(intent, REQUEST_CODE);
            }
        });

        fabSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String aboutInfo = "These are the username's info";
                User user = new User("userApp", 1234);
                Intent intent = new Intent(getApplicationContext(), AboutActivity.class);
                //trimiterea unui obiect de tip String sau a oricărei alte primitive prin Intent
                intent.putExtra(STRING_KEY, aboutInfo);
                //trimiterea unui obiect custom care implementează interfața Serializable
                intent.putExtra(USER_KEY, user);
                startActivity(intent);
            }
        });

        //setarea unui event de long click pe un rand dintr-un ListView
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long l) {
                Movie movie = movieList.get(position);
                movieList.remove(position);
                //stergerea unui film din Firebase
                firebaseController.removeMovie(movie);
                MovieAdapter adapter = new MovieAdapter(getApplicationContext(),
                        R.layout.rv_movies_row,
                        movieList,
                        getLayoutInflater());

                //setarea adaptorului pe listView
                listView.setAdapter(adapter);
                return true;

            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Movie movie = movieList.get(position);
                String aboutInfo = "The movie info";
                Intent intent = new Intent(getApplicationContext(), UpdateActivity.class);

                intent.putExtra(STRING_KEY, aboutInfo);
                startActivityForResult(intent, REQUEST_CODE);

                movieList.remove(position);

                firebaseController.removeMovie(movie);
                MovieAdapter adapter = new MovieAdapter(getApplicationContext(),
                        R.layout.rv_movies_row,
                        movieList,
                        getLayoutInflater());

                listView.setAdapter(adapter);
            }
        });
    }

    //crearea unui ValueEventListener pentru preluarea tuturor intrarilor din Firebase
    private ValueEventListener loadMovies() {
        return new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                movieList.clear();
                //parcurgerea tuturor intrarilor din Firebase
                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    //preluarea obiectului din Firebase
                    Movie movie = dataSnapshot.getValue(Movie.class);
                    movieList.add(movie);
                }

                MovieAdapter adapter = new MovieAdapter(getApplicationContext(),
                        R.layout.rv_movies_row,
                        movieList,
                        getLayoutInflater());

                //setarea adaptorului pe listView
                listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        };
    }





    //metodă folosită pentru a primi un rezultat de la o activitate secundară
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //conditiile ca rezultatul sa fie primit este ca requestCode-ul sa fie acelasi cu cel asteptat
        //resultCode-ul sa aiba valoarea RESULT_OK si sa existe date trimise între activități
        if(requestCode == REQUEST_CODE &&
                resultCode == RESULT_OK && data!=null){
            //getParcelableExtra() -> metoda disponibila la nivelul clasei Intent, fiind utilizata pentru preluare unui obiect custom din Intent.
            //clasa obiectului preluat implementeaza interfata Parcelable.
            //parametrul de intrare reprezinta cheia pe care s-a salvat obiectiul prin apelul metodei putExtra().
            Movie movie = data.getParcelableExtra(AddMovieActivity.MOVIE_KEY);
            if(movie!=null){
                movieList.add(movie);
                MovieAdapter currentAdapter =
                        (MovieAdapter) listView.getAdapter();
                currentAdapter.notifyDataSetChanged();

            }
        }
    }


}